package pt.iscte.poo.observer;

public interface Observer {
	void update(Observed source);
}
