package pt.iscte.poo.example;


public class MainExample {
	public static void main(String[] args) {
		EngineExample.getInstance().start();
				
	}
}
